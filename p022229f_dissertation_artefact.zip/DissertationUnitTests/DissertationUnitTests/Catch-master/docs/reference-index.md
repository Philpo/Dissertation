These are the currently documented areas of the framework. There is more to come.

Before looking at this material be sure to read the [tutorial](tutorial.md)

* [Command Line](command-line.md)
* [Assertion Macros](assertions.md)
* [Test cases and sections](test-cases-and-sections.md)
* [Logging Macros](logging.md)
* [Supplying your own main()](own-main.md)
* [Test fixtures](test-fixtures.md)
* [Visual Studio integration](vs/vs-index.md)

---

[Home](../README.md)