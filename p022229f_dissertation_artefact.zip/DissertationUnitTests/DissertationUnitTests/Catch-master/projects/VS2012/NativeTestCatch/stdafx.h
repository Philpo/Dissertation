// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"

// Headers for CppUnitTest
#pragma warning( disable:4505 )   // required for including CppUnitTest.h at /W4
#include "CppUnitTest.h"

// TODO: reference additional headers your program requires here
