// This file is only here to verify (to the extent possible) the self sufficiency of the header
#include "catch_ptr.hpp"
