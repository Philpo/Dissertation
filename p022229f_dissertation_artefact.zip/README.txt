To run the artifact:

1. Open Dissertation_main in Visual Studio
2. Open the properties for the Dissertation_main project
3. Ensure that the Command Arguments field under "Configuration Properties -> Debugging" has "-f test_params.xml"
4. Run the solution

WASD move and strafe the camera
Mouse movement rotates the camera
Space moves the camera up in the scene

Open the test_params.xml file to edit what tests are run


To run the unit tests:

1. Open DissertationUnitTests in Visual Studio
2. Run the tests by going to "Test -> Run -> Run all Tests" in the top toolbar